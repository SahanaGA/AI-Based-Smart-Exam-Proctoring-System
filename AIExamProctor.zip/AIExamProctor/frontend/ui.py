import streamlit as st
import cv2
import time
import random

st.set_page_config(page_title="AI Exam Proctoring", layout="centered")

# ---------------- SESSION STATES ----------------
if "page" not in st.session_state:
    st.session_state.page = "login"
if "logged_in_user" not in st.session_state:
    st.session_state.logged_in_user = None
if "activity_log" not in st.session_state:
    st.session_state.activity_log = []
if "cap" not in st.session_state:
    st.session_state.cap = None
if "users_db" not in st.session_state:
    st.session_state.users_db = {}
if "exam_running" not in st.session_state:
    st.session_state.exam_running = False

# ---------------- HELPER FUNCTIONS ----------------
def release_camera():
    if st.session_state.cap is not None:
        st.session_state.cap.release()
        st.session_state.cap = None
        cv2.destroyAllWindows()

def simulate_activity(frame):
    """
    Simulate activity detection for frontend.
    Only marks suspicious activity if random event occurs (for now)
    """
    activities = [
        "Normal Activity",
        "Using Mobile Phone",
        "Multiple Faces Detected",
        "Looking Away",
        "Using Book/Paper",
        "Tab Switch Detected"
    ]
    
    # 90% Normal, 10% Suspicious
    if random.random() < 0.1:
        activity = random.choice(activities[1:])  # suspicious
        status = "Suspicious"
    else:
        activity = "Normal Activity"
        status = "Normal"
    return activity, status

# ---------------- PAGES ----------------
def login_page():
    st.title("AI Exam Proctoring")

    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("Login"):
            db = st.session_state.users_db
            if username in db and db[username]["password"] == password:
                st.session_state.logged_in_user = username
                st.session_state.page = "exam"
                st.success("Login successful!")
                st.rerun()
            else:
                st.error("Invalid username or password")
    with col2:
        if st.button("Register"):
            st.session_state.page = "register"
            st.rerun()
    with col3:
        if st.button("Forgot Password?"):
            st.session_state.page = "forgot_password"
            st.rerun()

    if st.button("Recover Username"):
        st.session_state.page = "forgot_username"
        st.rerun()

def register_page():
    st.title("Create a New Account")
    user = st.text_input("Username")
    email = st.text_input("Email")
    password = st.text_input("Password", type="password")

    if st.button("Register"):
        db = st.session_state.users_db
        if user in db:
            st.error("Username already exists")
        elif any(u["email"] == email for u in db.values()):
            st.error("Email already registered")
        else:
            db[user] = {"password": password, "email": email}
            st.success("Account created successfully")
            st.session_state.page = "login"
            st.rerun()

def forgot_password_page():
    st.title("Reset Password")
    email = st.text_input("Enter your registered email")
    new_pass = st.text_input("Enter new password", type="password")

    if st.button("Reset Password"):
        db = st.session_state.users_db
        found = False
        for user, data in db.items():
            if data["email"] == email:
                db[user]["password"] = new_pass
                found = True
                st.success("Password reset successfully. Please log in again.")
                st.session_state.page = "login"
                st.rerun()
        if not found:
            st.error("Email not found in records.")

def forgot_username_page():
    st.title("Recover Username")
    email = st.text_input("Enter your registered email")
    if st.button("Find Username"):
        db = st.session_state.users_db
        for user, data in db.items():
            if data["email"] == email:
                st.success(f"Your username is: {user}")
                return
        st.error("No account found with that email.")

def exam_page():
    st.title("AI Exam Proctoring System")
    st.subheader(f"Welcome, {st.session_state.logged_in_user}")

    FRAME_WINDOW = st.image([])
    start_exam = st.button("Start Exam")
    stop_exam = st.button("Stop Exam")

    # ---------- Start Exam ----------
    if start_exam and not st.session_state.exam_running:
        st.session_state.exam_running = True
        st.session_state.activity_log = []

        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            st.error("⚠️ Cannot open webcam. Please check if it’s already in use.")
            st.session_state.exam_running = False
        else:
            st.session_state.cap = cap
            # Reduce resolution for smoother webcam
            st.session_state.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            st.session_state.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            st.success("Exam Started. Monitoring now...")

    # ---------- Exam Running ----------
    if st.session_state.exam_running:
        cap = st.session_state.cap
        if cap is None or not cap.isOpened():
            st.error("Webcam not available")
        else:
            # Read a single frame per rerun (avoids freezing)
            ret, frame = cap.read()
            if not ret:
                st.error("Cannot access webcam")
            else:
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                FRAME_WINDOW.image(frame_rgb)

                # Simulate detection
                activity, status = simulate_activity(frame)
                st.session_state.activity_log.append(
                    {"time": time.strftime("%H:%M:%S"), "activity": activity, "status": status}
                )

                if status == "Suspicious":
                    st.warning(f"⚠️ {activity}")
                else:
                    st.info("✅ Normal Activity")

    # ---------- Stop Exam ----------
    if stop_exam and st.session_state.exam_running:
        st.session_state.exam_running = False
        release_camera()
        st.session_state.page = "result"
        st.rerun()

def result_page():
    st.title("Exam Session Summary")
    if st.session_state.activity_log:
        for log in st.session_state.activity_log:
            icon = "🟢" if log["status"] == "Normal" else "🔴"
            st.write(f"{icon} [{log['time']}] {log['activity']} ({log['status']})")
    else:
        st.write("No activity recorded")

    if st.button("Logout"):
        release_camera()
        st.session_state.logged_in_user = None
        st.session_state.page = "login"
        st.rerun()

# ---------------- MAIN ----------------
if st.session_state.page == "login":
    login_page()
elif st.session_state.page == "register":
    register_page()
elif st.session_state.page == "forgot_password":
    forgot_password_page()
elif st.session_state.page == "forgot_username":
    forgot_username_page()
elif st.session_state.page == "exam":
    exam_page()
elif st.session_state.page == "result":
    result_page()
