import streamlit as st
import cv2

# -------------------------------
# Initialize session state
# -------------------------------
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "exam_started" not in st.session_state:
    st.session_state.exam_started = False

# -------------------------------
# Login Page
# -------------------------------
st.title("AI Exam Proctoring System")

username = st.text_input("Enter your username")
password = st.text_input("Enter password", type="password")

if st.button("Login"):
    if username and password:
        st.session_state.logged_in = True
        st.success(f"Welcome, {username}!")
    else:
        st.error("Please enter username and password")

# -------------------------------
# Start Exam Button
# -------------------------------
if st.session_state.logged_in:
    if st.button("Start Exam"):
        st.session_state.exam_started = True

# -------------------------------
# Stop Exam Button
# -------------------------------
if st.session_state.exam_started:
    if st.button("Stop Exam"):
        st.session_state.exam_started = False
        st.success("Exam Stopped")

# -------------------------------
# Display Webcam Feed
# -------------------------------
if st.session_state.exam_started:
    st.write("Exam Started. Webcam feed below:")

    cap = cv2.VideoCapture(0)  # 0 = default webcam
    frame_placeholder = st.empty()

    while st.session_state.exam_started:
        ret, frame = cap.read()
        if not ret:
            st.error("Failed to access webcam")
            break

        # Convert BGR (OpenCV default) to RGB (Streamlit)
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame_placeholder.image(frame, channels="RGB")

    # --- AI Detection Results ---
    st.subheader("AI Detection Status")

    # Placeholder for AI results
    st.write("Status: Normal")  # Later Member 2 will update this dynamically

    st.subheader("Exam Log / Report")
    st.write("Logs will appear here after AI processing.")  # Placeholder for Member 3
