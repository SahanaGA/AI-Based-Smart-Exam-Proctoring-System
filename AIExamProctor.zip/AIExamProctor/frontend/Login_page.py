import streamlit as st

# --- Page Configuration ---
st.set_page_config(page_title="AI Exam Proctoring", page_icon=":student:", layout="centered")

# --- Login Section ---
st.title("AI-Based Exam Proctoring System")

st.subheader("Login")

# Input fields
username = st.text_input("Enter your username")
exam_code = st.text_input("Enter exam code")

# Login button
if st.button("Login"):
    if username and exam_code:
        st.success(f"Welcome {username}! You are ready to start the exam.")
        st.session_state['logged_in'] = True
    else:
        st.error("Please enter both username and exam code.")
