# ai_model/face_detector.py
import cv2
import mediapipe as mp

class FaceDetector:
    def __init__(self, min_detection_confidence=0.5, model_selection=0):
        """
        model_selection: 0 (near) or 1 (far). Use 0 for webcam/close faces.
        """
        self.mp_face = mp.solutions.face_detection
        self.detector = self.mp_face.FaceDetection(
            model_selection=model_selection,
            min_detection_confidence=min_detection_confidence
        )

    def detect_faces(self, frame):
        """
        Input: BGR frame (numpy array)
        Returns: list of boxes (x, y, w, h) in pixel coords
        """
        h, w, _ = frame.shape
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.detector.process(rgb)

        boxes = []
        if results.detections:
            for det in results.detections:
                bbox_rel = det.location_data.relative_bounding_box
                x = int(bbox_rel.xmin * w)
                y = int(bbox_rel.ymin * h)
                bw = int(bbox_rel.width * w)
                bh = int(bbox_rel.height * h)

                # clamp to image
                x = max(0, x)
                y = max(0, y)
                bw = max(0, bw)
                bh = max(0, bh)

                boxes.append((x, y, bw, bh))
        return boxes
