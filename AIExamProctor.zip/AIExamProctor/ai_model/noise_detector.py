# ai_model/noise_detector.py
import sounddevice as sd
import numpy as np
from collections import deque
import threading

class NoiseDetector:
    """
    Callback-based noise detector using sounddevice.InputStream.

    Usage:
        nd = NoiseDetector(threshold=0.015, chunk_duration=0.2, samplerate=16000, consecutive_required=1, device=None)
        nd.start()
        ...
        nd.is_triggered()   # bool
        nd.last_value()     # last measured RMS/peak
        nd.stop()
    """

    def __init__(self,
                 threshold: float = 0.015,
                 chunk_duration: float = 0.2,
                 samplerate: int = 16000,
                 consecutive_required: int = 1,
                 device = None):
        """
        threshold: RMS/peak threshold (lower => more sensitive). Default 0.015 is good for speech.
        chunk_duration: seconds per audio block (0.15–0.3 recommended)
        samplerate: sampling rate (16000 is fine)
        consecutive_required: how many consecutive blocks above threshold are required to trigger
        device: sounddevice device index or name (None => default device)
        """
        self.threshold = float(threshold)
        self.sr = int(samplerate)
        # ensure blocksize at least 1
        self.blocksize = max(1, int(round(chunk_duration * self.sr)))
        self.consecutive_required = max(1, int(consecutive_required))
        self.device = device

        # internal state
        self._recent = deque(maxlen=self.consecutive_required)
        self._triggered = False
        self._last_value = 0.0
        self._lock = threading.Lock()
        self._stream = None
        self._running = False

    def _callback(self, indata, frames, time_info, status):
        # status may contain overflow/underflow info; we ignore it but you could log it
        if status:
            # small errors can be ignored; don't block detection
            pass

        # indata is shape (frames, channels)
        try:
            audio = indata[:, 0].astype(np.float32)  # use first channel
            # compute RMS and peak
            rms = float(np.sqrt(np.mean(audio ** 2))) if audio.size > 0 else 0.0
            peak = float(np.max(np.abs(audio))) if audio.size > 0 else 0.0
            value = max(rms, peak)

            with self._lock:
                self._last_value = value
                self._recent.append(value > self.threshold)
                # trigger if at least consecutive_required recent blocks are above threshold
                self._triggered = sum(self._recent) >= self.consecutive_required
        except Exception:
            # protect the callback from raising exceptions (which can stop the stream)
            with self._lock:
                self._last_value = 0.0
                self._triggered = False

    def start(self):
        """Start audio input stream. Safe to call multiple times."""
        if self._running:
            return
        try:
            self._stream = sd.InputStream(
                channels=1,
                samplerate=self.sr,
                blocksize=self.blocksize,
                callback=self._callback,
                dtype='float32',
                device=self.device
            )
            self._stream.start()
            self._running = True
        except Exception as e:
            # If the device cannot be opened, keep state consistent and raise a helpful error
            self._running = False
            self._stream = None
            raise RuntimeError(f"Failed to start NoiseDetector InputStream: {e}")

    def stop(self):
        """Stop the audio stream."""
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
        self._stream = None
        self._running = False
        # reset recent buffer so next start is clean
        with self._lock:
            self._recent.clear()
            self._triggered = False
            self._last_value = 0.0

    def is_triggered(self) -> bool:
        with self._lock:
            return bool(self._triggered)

    def last_value(self) -> float:
        """Return the last measured RMS/peak value (0.0..1.0 typically)."""
        with self._lock:
            return float(self._last_value)

    @staticmethod
    def list_devices():
        """Helper: list available input devices (useful for picking device index)."""
        return sd.query_devices()
