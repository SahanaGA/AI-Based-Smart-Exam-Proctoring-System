# ai_model/phone_detector.py
from ultralytics import YOLO
import cv2
import os

class PhoneDetector:
    def __init__(self, model_path=None, conf_threshold=0.35):
        """
        model_path: path to yolov8n.pt; if None, Ultralytics will download default.
        conf_threshold: detection confidence threshold to accept boxes.
        """
        if model_path:
            model_file = model_path
        else:
            # save model inside ai_model folder to avoid re-download in other dir
            model_file = os.path.join(os.path.dirname(__file__), "yolov8n.pt")
            # Ultralytics will auto-download if not present when YOLO(...) runs.

        self.model = YOLO(model_file)
        self.conf_threshold = conf_threshold

    def detect_phone(self, frame):
        """
        Input: BGR frame
        Returns: (count, boxes) where boxes = list of (x1,y1,x2,y2,conf)
        """
        # model expects RGB or BGR — Ultralytics accepts numpy array directly
        results = self.model.predict(frame, verbose=False, imgsz=640)
        boxes = []
        count = 0
        for r in results:
            # r.boxes is a tensor of shape (n,6): x1,y1,x2,y2,confidence,class
            for box in r.boxes:
                cls = int(box.cls.cpu().numpy())
                conf = float(box.conf.cpu().numpy())
                if cls == 67 and conf >= self.conf_threshold:  # COCO class 67 = cellphone
                    x1, y1, x2, y2 = map(int, box.xyxy.cpu().numpy()[0])
                    boxes.append((x1, y1, x2, y2, conf))
                    count += 1
        return count, boxes
