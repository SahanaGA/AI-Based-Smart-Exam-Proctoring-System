# backend/test_backend.py

import requests

url = "http://127.0.0.1:5000/event"

# Simulate a noise event
data = {
    "username": "Sirisha",
    "type": "noise_detected",
    "level": "high"
}

response = requests.post(url, json=data)
print(response.json())
