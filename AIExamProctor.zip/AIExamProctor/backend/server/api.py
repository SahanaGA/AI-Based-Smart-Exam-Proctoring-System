from flask import Flask, request, jsonify
from backend.server.logger import log_event
import os

# --- Flask App ---
app = Flask(__name__)

# Do NOT initialize heavy AI models at import time (they can fail if deps missing).
face_detector = None
noise_detector = None
phone_detector = None

def try_init_models():
    """
    Try to initialize optional models. If a model's dependency is missing,
    skip it and keep server running.
    """
    global face_detector, noise_detector, phone_detector

    if face_detector is None:
        try:
            from backend.ai_model.face_detector import FaceDetector
            face_detector = FaceDetector()
            print("FaceDetector initialized.")
        except Exception as e:
            face_detector = None
            print(f"FaceDetector not available: {e}")

    if noise_detector is None:
        try:
            from backend.ai_model.noise_detector import NoiseDetector
            noise_detector = NoiseDetector()
            print("NoiseDetector initialized.")
        except Exception as e:
            noise_detector = None
            print(f"NoiseDetector not available: {e}")

    if phone_detector is None:
        try:
            from backend.ai_model.phone_detector import PhoneDetector
            phone_detector = PhoneDetector()
            print("PhoneDetector initialized.")
        except Exception as e:
            phone_detector = None
            print(f"PhoneDetector not available: {e}")

@app.route("/event", methods=["POST"])
def receive_event():
    """
    Receives events from the frontend and logs them.
    Example frontend JSON:
    {
        "username": "Sirisha",
        "type": "noise_detected",
        "level": "high"
    }
    """
    data = request.get_json() or {}

    username = data.get("username", "unknown")
    event_type = data.get("type", "unknown")
    level = data.get("level")

    # Format log message
    if level:
        message = f"{event_type} - level: {level}"
    else:
        message = event_type

    # Write to CSV via logger.py
    log_event(username, message)

    return jsonify({"status": "logged"}), 200

if __name__ == "__main__":
    # Initialize optional models here (so import-time errors won't crash app)
    try_init_models()
    # Run the backend server
    app.run(host="0.0.0.0", port=5000, debug=True)
