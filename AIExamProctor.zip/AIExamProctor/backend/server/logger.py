import csv
from datetime import datetime
import os

LOG_FILE = os.path.join(os.path.dirname(__file__), "..", "logs", "logs.csv")

def log_event(username, event):
    # ensure log directory exists
    log_dir = os.path.dirname(LOG_FILE)
    os.makedirs(log_dir, exist_ok=True)

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    with open(LOG_FILE, "a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, username, event])

    print(f"[LOGGED] {timestamp} - {username} - {event}")
